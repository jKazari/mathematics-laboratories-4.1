#ifndef ALGORITHMS_H
#define ALGORITHMS_H

#include <iosfwd>
#include <vector>


namespace AiSD{

    using T = unsigned short;

    void print(const std::vector<T>& data);
    void print_pretty(const std::vector<T>& data);


} //namespace AiSD


/*
 *  operator<< must be declared in the global scop for lookup works, don't ask
 */

std::ostream& operator<<(std::ostream& os, const std::vector<AiSD::T>& data);



#endif
