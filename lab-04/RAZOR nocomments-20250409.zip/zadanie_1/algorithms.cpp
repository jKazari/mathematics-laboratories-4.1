
#include <iostream>

#include <iomanip>
#include <limits>

#include "algorithms.h"

namespace AiSD{

void print(const std::vector<T>& data){

    //ALERT quick-and-dirty, code duplicate, use operator<<
    for(size_t i = 0; i < data.size(); ++i){
        std::cout << data[i] << " ";
    }
}

void print_pretty(const std::vector<T>& data){

    //ALERT, magic constant
    constexpr auto ncols = 10;
    //NOTE: no magic constant here
    constexpr auto width = 2+std::numeric_limits<T>::digits10;

    //ALERT quick-and-dirty, code duplicate, use operator<<
    for(size_t i = 0; i < data.size(); ++i){
        std::cout << std::setw(width) << data[i];

        if( (i+1) % ncols == 0)
            std::cout << '\n';
    }

}

} //namespace AiSD


/*
 *  operator<< must be declared in the global scop for lookup works, don't ask
 */

std::ostream& operator<<(std::ostream& os, const std::vector<AiSD::T>& data){

    for(size_t i = 0; i < data.size(); ++i){
        os << data[i] << " ";
    }

    return os;
}
