/*
 * AiSD: preliminary task for Project 3.
 *
 * Task 1
 *
 * (c) AiSD 2020,2021,2025
 */

#include <iostream>
#include <vector>
#include <limits>

#include "algorithms.h"

using T = AiSD::T;  //convenience alias

int main(){

    // Greetings
    std::cout << "\n---- **** ---- **** ---- **** ---- **** ----\n";
    std::cout << " Hello, I have the greatest enthusiasm for this mission...\n";
    std::cout << "---- **** ---- **** ---- **** ---- **** ----\n\n";

    std::vector<T> data = {1,2,3,4,12345,
                            std::numeric_limits<T>::max(),std::numeric_limits<T>::min(),
                            1001,1002,1003,1004,1005, 18765,
                            2001,3002,4003,5004,6005, 18765,
                        };

    std::cout << "\n\nprint: \n";
    AiSD::print(data);

    std::cout << "\n\nprint_pretty: \n";
    AiSD::print_pretty(data);


    std::cout << "\n\noerator<<: \n";
    std::cout << data;


    // the end
    std::cout << "\n\nDone. Bye!\n";
    return 0;
}
