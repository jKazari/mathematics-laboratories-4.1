
#include <iostream>

#include <iomanip>
#include <limits>
#include <random>
#include <algorithm>

#include "algorithms.h"

namespace AiSD{

void print(const std::vector<T>& data){

    //ALERT quick-and-dirty, code duplicate, use operator<<
    for(size_t i = 0; i < data.size(); ++i){
        std::cout << data[i] << " ";
    }
}

void print_pretty(const std::vector<T>& data){

    //ALERT, magic constant
    constexpr auto ncols = 10;
    //NOTE: no magic constant here
    constexpr auto width = 2+std::numeric_limits<T>::digits10;

    //ALERT quick-and-dirty, code duplicate, use operator<<
    for(size_t i = 0; i < data.size(); ++i){
        std::cout << std::setw(width) << data[i];

        if( (i+1) % ncols == 0)
            std::cout << '\n';
    }

}


std::vector<T> RecordFactory::MakeRange ( size_t m, size_t M){

    // QUESTION: what is wrong with this function?

    std::vector<T> out;
    out.resize(M-m+1);

    // not modern, but works
    for(size_t i = 0; i<=out.size(); i++ )
        out[i] = m+i;

    std::cout << out.size();

    // moving std::vector not copying
    return out;
}

std::vector<T> RecordFactory::MakeRandom (size_t N, size_t m, size_t M){

    std::vector<T> out (N);

    std::random_device rd;
    std::default_random_engine prng ( rd() );
    std::uniform_int_distribution<> dist ( m,M );

    std::generate ( out.begin(),out.end(), [&]() { return ( dist ( prng ) ) ;} );

    // moving std::vector not copying
    return out;

    // moving std::vector not copying
    return out;
}




} //namespace AiSD


/*
 *  operator<< must be declared in the global scop for lookup works, don't ask
 */

std::ostream& operator<<(std::ostream& os, const std::vector<AiSD::T>& data){

    for(size_t i = 0; i < data.size(); ++i){
        os << data[i] << " ";
    }

    return os;
}
