/*
 * AiSD: preliminary task for Project 3.
 *
 * Task 2
 *
 * (c) AiSD 2020,2021,2025
 */

#include <iostream>
#include <vector>
#include <limits>

#include "algorithms.h"

using T = AiSD::T;  //convenience alias

int main(){

    // Greetings
    std::cout << "\n---- **** ---- **** ---- **** ---- **** ----\n";
    std::cout << " Hello, I have the greatest enthusiasm for this mission...\n";
    std::cout << "---- **** ---- **** ---- **** ---- **** ----\n\n";

    std::vector<T> data = {1,2,3,4,12345,
                            AiSD::Tmax,AiSD::Tmin,
                            1001,1002,1003,1004,1005, 18765,
                            2001,3002,4003,5004,6005, 18765
                        };

    AiSD::RecordFactory factory;


    data = factory.MakeRange(4,10);

    std::cout << "\n\nprint: \n";
    AiSD::print(data);


    data = factory.MakeRange(4142,4160);

    std::cout << "\n\nprint_pretty: \n";
    AiSD::print_pretty(data);


    // note MakeRandom(N,min,max)
    data = factory.MakeRandom(10,100,200);

    std::cout << "\n\noerator<<: \n";
    std::cout << data;


    data = factory.MakeRandom(100,10000,20000);

    std::cout << "\n\nprint_pretty: \n";
    AiSD::print_pretty(data);

    data = factory.MakeRandom(100);

    std::cout << "\n\nprint_pretty: \n";
    AiSD::print_pretty(data);

    // the end
    std::cout << "\n\nDone. Bye!\n";
    return 0;
}
