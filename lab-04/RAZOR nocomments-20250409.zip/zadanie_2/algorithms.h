#ifndef ALGORITHMS_H
#define ALGORITHMS_H

#include <iosfwd>
#include <vector>
#include <limits>


namespace AiSD{

    using T = unsigned short;
    constexpr auto Tmin = std::numeric_limits<T>::min();
    constexpr auto Tmax = std::numeric_limits<T>::max();

    void print(const std::vector<T>& data);
    void print_pretty(const std::vector<T>& data);



/*
 * RecordFactory
 *
 * random means with uniform distribution on T::min to T::max
 */
class RecordFactory
{

public:

    // m and M included
    std::vector<T> MakeRange ( size_t m, size_t M);
    std::vector<T> MakeRandom (size_t N, size_t m = Tmin, size_t M = Tmax );

private:

};

} //namespace AiSD


/*
 *  operator<< must be declared in the global scop for lookup works, don't ask
 */

std::ostream& operator<<(std::ostream& os, const std::vector<AiSD::T>& data);



#endif
