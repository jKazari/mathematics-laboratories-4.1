#ifndef ALGORITHMS_H
#define ALGORITHMS_H

#include <iosfwd>
#include <vector>


namespace AiSD{

    using T = usigned short;

    // just to check if everything works together, remove after
    void foo();

} //namespace AiSD


#endif
