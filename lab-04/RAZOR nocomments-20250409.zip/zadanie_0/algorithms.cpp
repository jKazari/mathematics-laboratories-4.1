
#include <iostream>

#include "algorithms.h"

namespace AiSD{

    // just to check if everything works together, remove after
    void foo() {};


} //namespace AiSD
