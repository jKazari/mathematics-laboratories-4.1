/*
 * AiSD: preliminary task for Project 3.
 *
 * Task 0
 *
 * (c) AiSD 2020,2021,2025
 */

#include <iostream>
#include <vector>

#include "algorithms.h"

using T = AiSD::T;  //convenience alias

int main(){

    // Greetings
    std::cout << "\n---- **** ---- **** ---- **** ---- **** ----\n";
    std::cout << " Hello, I have the greatest enthusiasm for this mission...\n";
    std::cout << "---- **** ---- **** ---- **** ---- **** ----\n\n";

    std::vector<T> data = {};

    // a function from algorithms
    // just to check if everything works together, remove after
    AiSD::foo();

    // the end
    std::cout << "\n\nDone. Bye!\n";
    return 0;    return 0;
}
